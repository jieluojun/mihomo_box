#!/system/bin/sh
# 卸载：先停掉后台服务（内核 / 开关监听 / WebUI 远程服务），拆掉 TUN 热点
# 转发规则，最后清工作目录。先停服务再拆规则，避免监听循环抢着把规则装回去。
WORKDIR=/data/adb/mihomo_box
IPT=/system/bin/iptables
IP6T=/system/bin/ip6tables

for f in core.pid switch.pid httpd.pid webui.pid; do   # webui.pid：旧版本的 httpd pid 文件名，一并兜底
  _p=$(cat "$WORKDIR/run/$f" 2>/dev/null)
  [ -n "$_p" ] && kill -9 "$_p" 2>/dev/null
done
pkill -f 'mihomo.sh _switch-loop' 2>/dev/null

# ---- 拆 TUN 热点转发规则（状态文件随目录删除，先读出来用）----
TUN_IF=$(grep '^iface=' "$WORKDIR/run/tunhs.state" 2>/dev/null | cut -d= -f2)
for i in "$TUN_IF" mihomo Meta0; do
  [ -n "$i" ] || continue
  [ -x "$IPT" ] && {
    "$IPT" -w -D FORWARD -i "$i" -j ACCEPT 2>/dev/null
    "$IPT" -w -D FORWARD -o "$i" -j ACCEPT 2>/dev/null
  }
  [ -x "$IP6T" ] && {
    "$IP6T" -w -D FORWARD -i "$i" -j ACCEPT 2>/dev/null
    "$IP6T" -w -D FORWARD -o "$i" -j ACCEPT 2>/dev/null
  }
done
# v6 拦截规则（ipv6=false 时装的）、策略路由 8995 直连绕过（规则+表）、
# 直连兜底链（filter/nat 的 mihomo_tunhs）与 rp_filter 原值一并还原
[ -x "$IP6T" ] && {
  "$IP6T" -w -D FORWARD -j REJECT 2>/dev/null
  "$IP6T" -w -D OUTPUT -p icmpv6 --icmpv6-type 134 -j DROP 2>/dev/null
}
[ -x "$IPT" ] && {
  "$IPT" -w -D FORWARD -j mihomo_tunhs 2>/dev/null
  "$IPT" -w -F mihomo_tunhs 2>/dev/null
  "$IPT" -w -X mihomo_tunhs 2>/dev/null
  "$IPT" -w -t nat -D POSTROUTING -j mihomo_tunhs 2>/dev/null
  "$IPT" -w -t nat -F mihomo_tunhs 2>/dev/null
  "$IPT" -w -t nat -X mihomo_tunhs 2>/dev/null
}
[ -x /system/bin/ip ] && {
  for _p in 8990 8991 8992 8993 8994 8995 8996 8997 8998 8999; do
    while /system/bin/ip rule del pref $_p 2>/dev/null; do :; done
    while /system/bin/ip -6 rule del pref $_p 2>/dev/null; do :; done
  done
  /system/bin/ip route flush table 8995 2>/dev/null
}
RP_A=$(grep '^rp_all=' "$WORKDIR/run/tunhs.rp" 2>/dev/null | cut -d= -f2)
RP_D=$(grep '^rp_def=' "$WORKDIR/run/tunhs.rp" 2>/dev/null | cut -d= -f2)
case "$RP_A" in ''|*[!0-9]*) ;; *) echo "$RP_A" > /proc/sys/net/ipv4/conf/all/rp_filter 2>/dev/null ;; esac
case "$RP_D" in ''|*[!0-9]*) ;; *) echo "$RP_D" > /proc/sys/net/ipv4/conf/default/rp_filter 2>/dev/null ;; esac

# ---- 拆 Tproxy 透明代理规则（mangle 链 + 策略路由 pref 100 / 表 2024，v4+v6）----
for _tpb in "$IPT" "$IP6T"; do
  [ -x "$_tpb" ] || continue
  for _tpc in mihomo_tp_pre mihomo_tp_out mihomo_tp_divert; do
    while "$_tpb" -w -t mangle -D PREROUTING -j "$_tpc" 2>/dev/null; do :; done
    while "$_tpb" -w -t mangle -D OUTPUT -p tcp -j "$_tpc" 2>/dev/null; do :; done
    while "$_tpb" -w -t mangle -D OUTPUT -p udp -j "$_tpc" 2>/dev/null; do :; done
    "$_tpb" -w -t mangle -F "$_tpc" 2>/dev/null
    "$_tpb" -w -t mangle -X "$_tpc" 2>/dev/null
  done
done
if [ -x /system/bin/ip ]; then
  while /system/bin/ip rule del pref 100 2>/dev/null; do :; done
  while /system/bin/ip -6 rule del pref 100 2>/dev/null; do :; done
  /system/bin/ip route flush table 2024 2>/dev/null
  /system/bin/ip -6 route flush table 2024 2>/dev/null
fi

# ---- 还原系统 IPv6（模块的「系统 IPv6」开关可能禁用过各网卡 v6）----
if [ -d /proc/sys/net/ipv6/conf ]; then
  for _v6f in /proc/sys/net/ipv6/conf/*/disable_ipv6; do
    [ -e "$_v6f" ] || continue
    case "$_v6f" in */conf/lo/*) continue ;; esac
    echo 0 2>/dev/null > "$_v6f"
  done
fi

rm -rf /data/adb/mihomo_box
