#!/system/bin/sh
# ============================================================
# 打包脚本：版本号一律取「当前时间」，不再手工维护
#
#   module.prop 的 version    = YYYYMMDD-HHMM（Asia/Shanghai）
#   module.prop 的 versionCode = YYM MDD HHMM（单调递增，供管理器判断新旧）
#   产物文件名                 = mihomo-box-<version>.zip
#
# 面板缓存：打包时不再生成任何缓存版本号（URL 无 ?v=N，SW 缓存名无 vNNN）。
# 「每次刷入都清缓存、使用当前版本面板」由 customize.sh 在刷入时写入的两个
# 指纹完成（sw.js 的 INSTALL_STAMP + ui/install.stamp），值就是本脚本
# 生成的模块版本戳 —— 刷一次变一次，不存在版本号脱节或忘记递增的问题。
# 本脚本只做自检：确认源码里没有残留 ?v=N、sw.js 的指纹占位行还在。
#
# 用法：  sh build.sh
# ============================================================
set -e
cd "$(dirname "$0")"

# —— 时间版本号（固定用北京时间，避免设备时区不同导致版本忽大忽小）——
STAMP=$(TZ='CST-8' date '+%Y%m%d-%H%M')
CODE=$(TZ='CST-8' date '+%y%m%d%H%M')

echo "版本: $STAMP  (versionCode=$CODE)"
echo "缓存: 无版本号（刷入时按 $STAMP 打指纹，打开面板即清旧缓存）"

# 写回 module.prop
if [ -f module.prop ]; then
  sed -i "s/^version=.*/version=$STAMP/; s/^versionCode=.*/versionCode=$CODE/" module.prop
fi

# 自检 1：面板文件里不允许再出现 ?v=N 版本号（清缓存已不依赖它）
if grep -rlE '\?v=[0-9]+' webroot 2>/dev/null | grep -q .; then
  echo "  ⚠ 仍残留 ?v=N 版本号：$(grep -rlE '\?v=[0-9]+' webroot 2>/dev/null | tr '\n' ' ')"
fi

# 自检 2：sw.js 必须保留 INSTALL_STAMP 占位行，否则刷入时打不上指纹
grep -q "^const INSTALL_STAMP = 'dev';" webroot/ui/sw.js 2>/dev/null \
  || echo "  ⚠ sw.js 缺少 INSTALL_STAMP 占位行（刷入时无法标记指纹，请检查是否被改成固定值）"

# 自检 3：打包产物里不带 install.stamp —— 它只在刷入时由 customize.sh 现场生成
rm -f webroot/ui/install.stamp 2>/dev/null

# 自检 4：webroot/ 下为面板根目录，包含跳转页 index.html + ui/ + tools/
# 旧版要求仅 index.html，现 ui/tools 已移入 webroot，允许这三项
if [ ! -f webroot/index.html ] || [ ! -d webroot/ui ] || [ ! -d webroot/tools ]; then
  echo "  ⚠ webroot/ 结构异常，期望包含 index.html、ui/、tools/，当前：$(ls -A webroot 2>/dev/null | tr '\n' ' ')"
fi
# 额外检查：webroot 根下不应直接出现面板文件（js/css/cgi-bin 等），避免双份
if [ -d webroot/js ] || [ -d webroot/css ] || [ -d webroot/cgi-bin ]; then
  echo "  ⚠ webroot/ 根下不应直接包含 js/css/cgi-bin，面板文件应在 webroot/ui/ 下"
fi

# 跳转页烘焙：包里的 webroot/index.html 永远从脚本模板现场生成（出厂默认端口），
# 保证它和运行时 web_sync_webroot() 写出来的同源，不会漂移。
sh scripts/mihomo.sh webroot-render 55555 "" > webroot/index.html

# 前端 JS 单文件极速打包：消除 20 次瀑布网络往返，秒级直出
if command -v npx >/dev/null 2>&1; then
  npx esbuild webroot/ui/js/app.js --bundle --minify --format=esm --outfile=webroot/ui/js/app.bundle.js >/dev/null 2>&1 || true
fi

# 全部自有 shell/JS 做语法检查；不在构建机执行 Android 控制脚本。
for file in ./*.sh scripts/*.sh webroot/ui/cgi-bin/*.sh; do sh -n "$file"; done
for file in webroot/ui/js/*.js webroot/ui/js/vendor/*.js webroot/ui/sw.js; do
  node --input-type=module --check < "$file"
done
# 缺少依赖也是失败；只允许操作者显式跳过，不再把失败包装成成功。
if [ "${SKIP_TESTS:-0}" = "1" ] || [ ! -d tests ]; then
  echo "提示：未执行回归测试（SKIP_TESTS=1 或 tests 目录不存在）"
else
  (cd tests && node -e "require('jsdom')" 2>/dev/null) || { echo "  缺少 jsdom：请先 cd tests && npm install"; exit 1; }
  node tests/http-transport.mjs
  node tests/lifecycle.mjs
  node tests/app-info.mjs
  node tests/app-metadata-unified.mjs
  node tests/packages.mjs
  node tests/proxy-mode-groups.mjs
  node tests/proxy-group-icons.mjs
  node tests/proxy-health.mjs
  node tests/proxy-layout-stability.mjs
  node tests/controller-direct-reads.mjs
  node tests/controller-api.mjs
  node tests/subscription-progress.mjs
  node tests/dashboard-header.mjs
  node tests/theme-boot.mjs
  node tests/sw-precache.mjs
  node tests/e2e-boot.mjs
  node tests/dashboard-skeleton.mjs
  node tests/dashboard-logbox-blank-card.mjs
  node tests/smoke-all-pages.mjs
  node tests/service-restart-on-save.mjs
  node tests/status-invalidate.mjs
  node tests/tun-card.mjs
  node tests/ebpf-fields.mjs
  node tests/ebpf-enable-switch.mjs
  node tests/ebpf-inbound-listener.mjs
  node tests/ebpf-env-check.mjs
  node tests/tproxy-status.mjs
  node tests/source-sheet.mjs
  node tests/wrap-chip-drag.mjs
  node tests/sheet-grab.mjs
  node tests/config-test-feedback.mjs
  node tests/proxy-uri.mjs
  node tests/proxy-uri-layout.mjs
  node tests/proxy-invalidate.mjs
  node tests/core-lifecycle-api.mjs
  node tests/api-error-body.mjs
  node tests/ui-log-levels.mjs
  node tests/interaction-idle.mjs
  node tests/panel-background.mjs
  node tests/webui-addr-autoscan.mjs
  node tests/config-references.mjs
  node tests/outbound-flow.mjs
  python3 tests/backend-safety.py
  python3 tests/live-cache.py
  python3 tests/switch-loop-idle.py
  python3 tests/switch-transitions.py
  python3 tests/webui-addrs.py
  python3 tests/webui-port-guard.py
  python3 tests/ipv6-apply.py
  python3 tests/webroot-jump.py
  python3 tests/tproxy-applist.py
  python3 tests/ebpf-enabled-backend.py
  python3 tests/http-client-memory.py
  python3 tests/gzip-compat.py
  python3 tests/core-import.py
  python3 tests/customize-install-action.py
  python3 tests/customize-first-install.py
  node tests/core-import-ui.mjs
fi
OUTDIR=${OUTDIR:-..}
mkdir -p "$OUTDIR"
OUTDIR=$(cd "$OUTDIR" && pwd)
case "$OUTDIR/" in
  "$(pwd)/"*) echo "错误：产物目录不能位于源码目录内"; exit 1 ;;
esac
OUT="$OUTDIR/mihomo-box-$STAMP.zip"
rm -f "$OUT"
zip -r -q "$OUT" . -x '*.zip' 'node_modules/*' '*/node_modules/*' '.git/*' '*/__pycache__/*' 'tests/*' 'tests/node_modules/*'
echo "产物: $OUT"
ls -la "$OUT"
