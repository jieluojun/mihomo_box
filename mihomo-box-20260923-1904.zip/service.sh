#!/system/bin/sh
# 开机启动服务（由 KernelSU/Magisk 在 boot_completed 后执行，运行在后台，
# 不受管理器 App 生命周期影响；无守护进程，仅按自启设置决定是否启动内核）
# 面板 HTTP 服务随开机常驻（管理器界面与浏览器共用它，由 boot 拉起）。
MODDIR=${0%/*}
WORKDIR=/data/adb/mihomo_box

# 等待系统启动完成
until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 5
done
# 等待网络基本就绪（失败也不阻塞启动）
sh "$MODDIR/scripts/mihomo.sh" wait-net >/dev/null 2>&1
sleep 3

sh "$MODDIR/scripts/mihomo.sh" boot
exit 0
