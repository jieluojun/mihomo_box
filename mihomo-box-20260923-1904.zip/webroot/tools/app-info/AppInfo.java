import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Looper;
import android.util.Base64;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.Method;
import java.util.HashSet;

/** Read-only metadata helper. No list enumeration or package/config modification. */
public final class AppInfo {
    public static void main(String[] args) {
        try {
            if (Looper.myLooper() == null) Looper.prepareMainLooper();
            Class<?> type = Class.forName("android.app.ActivityThread");
            Method systemMain = type.getDeclaredMethod("systemMain");
            systemMain.setAccessible(true);
            Object thread = systemMain.invoke(null);
            Method getContext = type.getDeclaredMethod("getSystemContext");
            getContext.setAccessible(true);
            Context context = (Context) getContext.invoke(thread);
            PackageManager pm = context.getPackageManager();
            OutputStreamWriter out = new OutputStreamWriter(System.out, "UTF-8");
            out.write("[");
            boolean labelsOnly = args.length > 0 && "--labels".equals(args[0]);
            boolean iconsOnly = args.length > 0 && "--icons".equals(args[0]);
            boolean first = true;
            HashSet<String> seen = new HashSet<String>();
            for (String name : args) {
                if (!name.matches("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)*") || !seen.add(name)) continue;
                JSONObject row = new JSONObject();
                row.put("packageName", name);
                if (!iconsOnly) row.put("appLabel", name);
                try {
                    ApplicationInfo app = pm.getApplicationInfo(name, 0);
                    row.put("uid", app.uid);
                    if (!iconsOnly) {
                        CharSequence label = pm.getApplicationLabel(app);
                        if (label != null && label.length() > 0) row.put("appLabel", label.toString());
                    }
                    if (!labelsOnly) {
                    Bitmap bitmap = null;
                    try {
                        Drawable icon = pm.getApplicationIcon(app);
                        if (icon != null) {
                            bitmap = Bitmap.createBitmap(48, 48, Bitmap.Config.ARGB_8888);
                            Canvas canvas = new Canvas(bitmap);
                            Rect old = new Rect(icon.getBounds());
                            icon.setBounds(0, 0, 48, 48);
                            icon.draw(canvas);
                            icon.setBounds(old);
                            ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes);
                            if (bytes.size() <= 32768) row.put("icon", "data:image/png;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP));
                        }
                    } catch (Throwable ignored) {
                        // A broken/adaptive resource must not hide its app or its label.
                    } finally {
                        if (bitmap != null) bitmap.recycle();
                    }
                    }
                } catch (Throwable ignored) {
                    // Package may have been uninstalled since the list was read.
                }
                if (!first) out.write(",");
                first = false;
                out.write(row.toString());
                out.flush();
            }
            out.write("]");
            out.flush();
            System.exit(0);
        } catch (Throwable error) {
            System.err.println("App metadata unavailable: " + error);
            System.exit(1);
        }
    }
}
