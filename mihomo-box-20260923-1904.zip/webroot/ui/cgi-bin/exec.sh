#!/system/bin/sh
# 注：httpd 已通过 httpd.conf 指定解释器调用本脚本，不依赖此 shebang 与执行位。
# ============================================================
# WebUI 浏览器访问桥：把 HTTP 请求转成 root shell 执行
# 由 busybox httpd 以 CGI 方式调用（httpd 本身以 root 运行）
#
# 请求：POST /cgi-bin/exec.sh
#   头  X-Mihomo-Token: <令牌>   （或 ?t=<令牌>）
#   体  base64(shell 命令)
# 响应：{"errno":N,"stdout_b64":"...","stderr_b64":"..."}
#
# 之所以整段 base64：命令里常含引号/换行/中文（写配置就是 base64 管道），
# 直接明文传会被 URL 解码与 shell 二次解析破坏。
# ============================================================

WORKDIR=/data/adb/mihomo_box
RUNDIR=$WORKDIR/run
TOKEN_FILE=$RUNDIR/webui.token
SETTINGS=$WORKDIR/module-settings.conf

export PATH="/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:/data/adb/modules/busybox-ndk/system/xbin:$PATH:/sbin:/system/bin:/system/xbin"

# base64 回退到 busybox：Magisk 的 busybox 是单文件 /data/adb/magisk/busybox，
# 不在 PATH 中，必须按绝对路径找，否则纯 Magisk 环境下这里会直接失效。
B64="base64"
if ! command -v base64 >/dev/null 2>&1; then
  for _bb in "$(command -v busybox 2>/dev/null)" /data/adb/magisk/busybox \
             /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
             /data/adb/modules/busybox-ndk/system/xbin/busybox; do
    [ -n "$_bb" ] && [ -x "$_bb" ] && { B64="$_bb base64"; break; }
  done
  unset _bb
fi

json_out() {
  # $1 errno  $2 stdout文件  $3 stderr文件
  #
  # 必须「流式拼接」，绝不能把 base64 结果用 $(...) 塞进 printf 的参数。
  # 以前是 printf '...%s...' "$($B64 < out | tr -d '\r\n')"：整段 base64 先被
  # shell 收进内存当参数，再一次性展开 —— /providers/proxies 这种上百节点的
  # 大响应（几 MB，base64 后更大）走这条路，CGI 进程会在拼参数时被拖垮，
  # httpd 只收到一个空响应体，前端 res.json() 直接抛
  # "SyntaxError: Unexpected end of JSON input"，表现为「节点类型全部未知」。
  # 分五次写出去，管道直连 socket，内存只占一个块，与响应大小无关。
  printf 'Content-Type: application/json\r\n'
  printf 'Cache-Control: no-store\r\n'
  printf '\r\n'
  printf '{"errno":%s,"stdout_b64":"' "$1"
  $B64 < "$2" 2>/dev/null | tr -d '\r\n'
  printf '","stderr_b64":"'
  $B64 < "$3" 2>/dev/null | tr -d '\r\n'
  printf '"}'
}

fail() {
  # $1 HTTP 状态行  $2 消息
  printf 'Status: %s\r\n' "$1"
  printf 'Content-Type: application/json\r\n\r\n'
  printf '{"errno":-1,"error":"%s"}' "$2"
  exit 0
}

# ---------- 令牌校验 ----------
# 开关默认关闭：局域网内直接用 IP:端口 访问，不需要令牌。
AUTH=$(grep -E '^webui_auth=' "$SETTINGS" 2>/dev/null | head -1 | cut -d= -f2-)
if [ "$AUTH" = "true" ]; then
  [ -s "$TOKEN_FILE" ] || fail "503 Unavailable" "token missing"
  WANT=$(cat "$TOKEN_FILE" 2>/dev/null)
  GOT=$HTTP_X_MIHOMO_TOKEN
  if [ -z "$GOT" ]; then
    GOT=$(echo "$QUERY_STRING" | tr '&' '\n' | sed -n 's/^t=//p' | head -1)
  fi
  [ -n "$GOT" ] && [ "$GOT" = "$WANT" ] || fail "401 Unauthorized" "bad token"
fi

# ---------- 读取请求体 ----------
[ "$REQUEST_METHOD" = "POST" ] || fail "405 Method Not Allowed" "POST only"
LEN=${CONTENT_LENGTH:-0}
case "$LEN" in ''|*[!0-9]*) LEN=0 ;; esac
[ "$LEN" -gt 0 ] || fail "400 Bad Request" "empty body"
[ "$LEN" -le 8000000 ] || fail "413 Too Large" "body too large"

# 请求文件含 root 命令和输出，使用私有目录，并在所有正常/信号退出路径清理。
umask 077
mkdir -p "$RUNDIR" 2>/dev/null || fail "500 Internal Server Error" "runtime directory unavailable"
TMPDIR=$(mktemp -d "$RUNDIR/webui.cgi.XXXXXX") || fail "500 Internal Server Error" "temporary directory unavailable"
TMP=$TMPDIR/request
trap 'rm -rf "$TMPDIR"' 0
trap 'exit 1' HUP INT TERM
# 逐字节读（dd bs=1）在保存大 config.yaml 时是几十万次系统调用，慢到能被
# 当成超时；head -c 一次读完。极简环境没有 head 时再退回 dd。
head -c "$LEN" > "$TMP.b64" 2>/dev/null
[ -s "$TMP.b64" ] || dd bs=1 count="$LEN" 2>/dev/null > "$TMP.b64"
ACTUAL=$(wc -c < "$TMP.b64" | tr -d ' ')
[ "$ACTUAL" = "$LEN" ] || fail "400 Bad Request" "incomplete body"

# 解码到文件而非变量：Linux 单个 argv 参数上限 128KiB(MAX_ARG_STRLEN)，
# 保存较大的 config.yaml 时 sh -c "$CMD" 会直接 E2BIG 失败。
$B64 -d < "$TMP.b64" > "$TMP.cmd" 2>/dev/null || fail "400 Bad Request" "decode failed"
rm -f "$TMP.b64"
[ -s "$TMP.cmd" ] || { rm -f "$TMP.cmd"; fail "400 Bad Request" "decode failed"; }

# ---------- 执行 ----------
# 以脚本文件方式执行，命令长度只受磁盘限制，不再受 argv 上限约束
cd / 2>/dev/null
sh "$TMP.cmd" > "$TMP.out" 2> "$TMP.err"
RC=$?
json_out "$RC" "$TMP.out" "$TMP.err"
rm -f "$TMP.cmd" "$TMP.out" "$TMP.err"
exit 0
