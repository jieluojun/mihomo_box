#!/system/bin/sh
# 早期启动阶段：确保运行目录存在
WORKDIR=/data/adb/mihomo_box
[ -d "$WORKDIR" ] && mkdir -p "$WORKDIR/run" 2>/dev/null
exit 0
